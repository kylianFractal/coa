package com.photovoltaique.app.viewmodel

import android.app.Application
import android.location.Geocoder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import com.photovoltaique.app.data.database.AppDatabase
import com.photovoltaique.app.data.entity.Client
import com.photovoltaique.app.data.entity.TypeIntervention
import com.photovoltaique.app.data.repository.ClientRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class FormState(
    val nom: String = "",
    val prenom: String = "",
    val adresse: String = "",
    val cout: String = "",
    val type: TypeIntervention = TypeIntervention.MIS_A_NEUF,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class ClientViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ClientRepository(AppDatabase.getDatabase(application).clientDao())

    val clients: StateFlow<List<Client>> = repo.allClients.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _form = MutableStateFlow(FormState())
    val formState: StateFlow<FormState> = _form.asStateFlow()

    private val _selected = MutableStateFlow<Client?>(null)
    val selectedClient: StateFlow<Client?> = _selected.asStateFlow()

    fun onNomChange(v: String)     { _form.value = _form.value.copy(nom = v, errorMessage = null) }
    fun onPrenomChange(v: String)  { _form.value = _form.value.copy(prenom = v, errorMessage = null) }
    fun onAdresseChange(v: String) { _form.value = _form.value.copy(adresse = v, errorMessage = null) }
    fun onCoutChange(v: String)    { _form.value = _form.value.copy(cout = v, errorMessage = null) }
    fun onTypeChange(v: TypeIntervention) { _form.value = _form.value.copy(type = v) }
    fun selectClient(c: Client?)   { _selected.value = c }
    fun resetForm()                { _form.value = FormState() }
    fun clearSuccess()             { _form.value = _form.value.copy(successMessage = null) }

    fun deleteClient(client: Client) = viewModelScope.launch {
        repo.delete(client)
        if (_selected.value?.id == client.id) _selected.value = null
    }

    fun saveWithAddress() {
        val s = _form.value
        if (s.nom.isBlank() || s.prenom.isBlank() || s.adresse.isBlank()) {
            _form.value = s.copy(errorMessage = "Remplissez tous les champs obligatoires"); return
        }
        val cout = s.cout.toDoubleOrNull() ?: run {
            _form.value = s.copy(errorMessage = "Coût invalide"); return
        }
        viewModelScope.launch {
            _form.value = _form.value.copy(isLoading = true, errorMessage = null)
            val coords = geocode(s.adresse)
            if (coords == null) {
                _form.value = _form.value.copy(isLoading = false, errorMessage = "Adresse introuvable")
                return@launch
            }
            repo.insert(Client(nom = s.nom.trim(), prenom = s.prenom.trim(), adresse = s.adresse.trim(),
                cout = cout, type = s.type, latitude = coords.latitude, longitude = coords.longitude))
            _form.value = FormState(successMessage = "Client ajouté !")
        }
    }

    fun saveWithGps(pos: LatLng) {
        val s = _form.value
        if (s.nom.isBlank() || s.prenom.isBlank() || s.adresse.isBlank()) {
            _form.value = s.copy(errorMessage = "Remplissez tous les champs obligatoires"); return
        }
        val cout = s.cout.toDoubleOrNull() ?: run {
            _form.value = s.copy(errorMessage = "Coût invalide"); return
        }
        viewModelScope.launch {
            repo.insert(Client(nom = s.nom.trim(), prenom = s.prenom.trim(), adresse = s.adresse.trim(),
                cout = cout, type = s.type, latitude = pos.latitude, longitude = pos.longitude))
            _form.value = FormState(successMessage = "Client ajouté !")
        }
    }

    private suspend fun geocode(address: String): LatLng? = withContext(Dispatchers.IO) {
        try {
            @Suppress("DEPRECATION")
            Geocoder(getApplication(), Locale.FRANCE).getFromLocationName(address, 1)
                ?.firstOrNull()?.let { LatLng(it.latitude, it.longitude) }
        } catch (e: Exception) { null }
    }
}
