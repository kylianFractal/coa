package com.photovoltaique.app.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import com.photovoltaique.app.data.entity.TypeIntervention
import com.photovoltaique.app.ui.components.ClientBottomSheet
import com.photovoltaique.app.viewmodel.ClientViewModel

private val FRANCE = LatLng(46.603354, 1.888334)

@SuppressLint("MissingPermission")
@Composable
fun MapScreen(viewModel: ClientViewModel, onAddClientClick: () -> Unit) {
    val context = LocalContext.current
    val clients by viewModel.clients.collectAsStateWithLifecycle()
    val selected by viewModel.selectedClient.collectAsStateWithLifecycle()

    var hasPerms by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { p ->
        hasPerms = p[Manifest.permission.ACCESS_FINE_LOCATION] == true || p[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }
    val cam = rememberCameraPositionState { position = CameraPosition.fromLatLngZoom(FRANCE, 6f) }

    LaunchedEffect(Unit) {
        if (!hasPerms) launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    LaunchedEffect(hasPerms) {
        if (hasPerms) {
            LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener { loc ->
                loc?.let { cam.move(CameraUpdateFactory.newLatLngZoom(LatLng(it.latitude, it.longitude), 12f)) }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cam,
            properties = MapProperties(isMyLocationEnabled = hasPerms),
            uiSettings = MapUiSettings(myLocationButtonEnabled = false, zoomControlsEnabled = true)
        ) {
            clients.forEach { client ->
                val hue = if (client.type == TypeIntervention.MIS_A_NEUF)
                    BitmapDescriptorFactory.HUE_GREEN else BitmapDescriptorFactory.HUE_ORANGE
                Marker(
                    state = MarkerState(LatLng(client.latitude, client.longitude)),
                    title = "${client.prenom} ${client.nom}",
                    snippet = client.type.label,
                    icon = BitmapDescriptorFactory.defaultMarker(hue),
                    onClick = { viewModel.selectClient(client); true }
                )
            }
        }

        // Légende
        Card(
            modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.93f)),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(Color(0xFF2ECC71), CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text("Mis à neuf", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(Color(0xFFFF8C00), CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text("Reprise étanchéité", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Compteur clients
        Card(
            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(20.dp)
        ) {
            Text(
                "${clients.size} client${if (clients.size > 1) "s" else ""}",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimary
            )
        }

        // Bouton GPS
        if (hasPerms) {
            SmallFloatingActionButton(
                onClick = {
                    LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener { loc ->
                        loc?.let { cam.move(CameraUpdateFactory.newLatLngZoom(LatLng(it.latitude, it.longitude), 14f)) }
                    }
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 88.dp),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Icon(Icons.Default.MyLocation, "Ma position", tint = MaterialTheme.colorScheme.primary)
            }
        }

        // FAB Ajouter
        FloatingActionButton(
            onClick = onAddClientClick,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            Icon(Icons.Default.Add, "Ajouter un client", tint = MaterialTheme.colorScheme.onPrimary)
        }
    }

    selected?.let { c ->
        ClientBottomSheet(
            client = c,
            onDismiss = { viewModel.selectClient(null) },
            onDelete = { viewModel.deleteClient(it) }
        )
    }
}
