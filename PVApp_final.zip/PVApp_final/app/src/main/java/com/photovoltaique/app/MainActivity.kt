package com.photovoltaique.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.photovoltaique.app.ui.screens.AddClientScreen
import com.photovoltaique.app.ui.screens.MapScreen
import com.photovoltaique.app.ui.theme.PhotovoltaiqueAppTheme
import com.photovoltaique.app.viewmodel.ClientViewModel

class MainActivity : ComponentActivity() {
    private val vm: ClientViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PhotovoltaiqueAppTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val nav = rememberNavController()
                    NavHost(nav, startDestination = "map") {
                        composable("map") { MapScreen(vm) { nav.navigate("add") } }
                        composable("add") { AddClientScreen(vm) { nav.popBackStack() } }
                    }
                }
            }
        }
    }
}
