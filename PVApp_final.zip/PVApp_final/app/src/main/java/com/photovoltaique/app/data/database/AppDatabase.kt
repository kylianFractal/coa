package com.photovoltaique.app.data.database

import android.content.Context
import androidx.room.*
import com.photovoltaique.app.data.dao.ClientDao
import com.photovoltaique.app.data.entity.Client
import com.photovoltaique.app.data.entity.TypeIntervention

class Converters {
    @TypeConverter
    fun fromType(value: TypeIntervention): String = value.name
    @TypeConverter
    fun toType(value: String): TypeIntervention = TypeIntervention.valueOf(value)
}

@Database(entities = [Client::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getDatabase(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "pv_db")
                    .build().also { INSTANCE = it }
            }
    }
}
