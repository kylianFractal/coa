package com.photovoltaique.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TypeIntervention(val label: String) {
    MIS_A_NEUF("Mis à neuf"),
    REPRISE_ETANCHEITE("Reprise d'étanchéité")
}

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nom: String,
    val prenom: String,
    val adresse: String,
    val cout: Double,
    val type: TypeIntervention,
    val latitude: Double,
    val longitude: Double
)
