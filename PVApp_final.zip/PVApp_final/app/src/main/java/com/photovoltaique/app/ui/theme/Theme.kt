package com.photovoltaique.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val Dark = darkColorScheme(
    primary = SolarOrange, secondary = SolarGreen, tertiary = SolarBlue,
    background = DarkBg, surface = DarkSurface,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    onBackground = androidx.compose.ui.graphics.Color.White,
    onSurface = androidx.compose.ui.graphics.Color.White
)
private val Light = lightColorScheme(
    primary = SolarOrange, secondary = SolarGreen, tertiary = SolarBlue
)

@Composable
fun PhotovoltaiqueAppTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (dark) Dark else Light
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = colors.primary.toArgb()
        WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = !dark
    }
    MaterialTheme(colorScheme = colors, typography = Typography, content = content)
}
