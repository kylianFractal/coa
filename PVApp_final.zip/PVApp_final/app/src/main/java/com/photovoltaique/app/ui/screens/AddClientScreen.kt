package com.photovoltaique.app.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.photovoltaique.app.data.entity.TypeIntervention
import com.photovoltaique.app.viewmodel.ClientViewModel

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddClientScreen(viewModel: ClientViewModel, onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val form by viewModel.formState.collectAsStateWithLifecycle()
    var dropdownOpen by remember { mutableStateOf(false) }
    var gpsPos by remember { mutableStateOf<LatLng?>(null) }
    var useGps by remember { mutableStateOf(false) }

    var hasPerms by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { p ->
        hasPerms = p[Manifest.permission.ACCESS_FINE_LOCATION] == true || p[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    LaunchedEffect(form.successMessage) {
        if (form.successMessage != null) { onNavigateBack(); viewModel.clearSuccess() }
    }

    fun fetchGps() {
        if (hasPerms) {
            LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener { loc ->
                loc?.let { gpsPos = LatLng(it.latitude, it.longitude); useGps = true }
            }
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ajouter un client") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.resetForm(); onNavigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Informations personnelles
            Text("Informations personnelles", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))

            OutlinedTextField(
                value = form.nom, onValueChange = viewModel::onNomChange,
                label = { Text("Nom *") },
                leadingIcon = { Icon(Icons.Default.Person, null) },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = form.prenom, onValueChange = viewModel::onPrenomChange,
                label = { Text("Prénom *") },
                leadingIcon = { Icon(Icons.Default.Person, null) },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )

            // Intervention
            Text("Intervention", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))

            OutlinedTextField(
                value = form.cout, onValueChange = viewModel::onCoutChange,
                label = { Text("Coût (€) *") },
                leadingIcon = { Icon(Icons.Default.EuroSymbol, null) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )

            ExposedDropdownMenuBox(
                expanded = dropdownOpen,
                onExpandedChange = { dropdownOpen = it },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = form.type.label, onValueChange = {},
                    readOnly = true, label = { Text("Type d'intervention *") },
                    leadingIcon = { Icon(Icons.Default.Build, null) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(dropdownOpen) },
                    modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                    TypeIntervention.entries.forEach { t ->
                        DropdownMenuItem(text = { Text(t.label) }, onClick = { viewModel.onTypeChange(t); dropdownOpen = false })
                    }
                }
            }

            // Localisation
            Text("Localisation", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))

            OutlinedTextField(
                value = form.adresse,
                onValueChange = { viewModel.onAdresseChange(it); useGps = false },
                label = { Text("Adresse complète *") },
                leadingIcon = { Icon(Icons.Default.LocationOn, null) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2, maxLines = 3,
                placeholder = { Text("Ex: 12 Rue de la Paix, 75001 Paris") }
            )

            OutlinedButton(onClick = ::fetchGps, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.MyLocation, null)
                Spacer(Modifier.width(8.dp))
                Text(if (useGps && gpsPos != null) "Position GPS utilisée" else "Utiliser ma position GPS")
            }

            if (useGps && gpsPos != null) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(
                        "GPS: %.5f, %.5f".format(gpsPos!!.latitude, gpsPos!!.longitude),
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            form.errorMessage?.let { err ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text(err, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Button(
                onClick = { if (useGps && gpsPos != null) viewModel.saveWithGps(gpsPos!!) else viewModel.saveWithAddress() },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = !form.isLoading
            ) {
                if (form.isLoading) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Enregistrer le client", style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
