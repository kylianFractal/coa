package com.photovoltaique.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EuroSymbol
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.photovoltaique.app.data.entity.Client
import com.photovoltaique.app.data.entity.TypeIntervention
import com.photovoltaique.app.ui.theme.SolarGreen
import com.photovoltaique.app.ui.theme.SolarOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientBottomSheet(client: Client, onDismiss: () -> Unit, onDelete: (Client) -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${client.prenom} ${client.nom}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                val (col, lbl) = when (client.type) {
                    TypeIntervention.MIS_A_NEUF -> Pair(SolarGreen, "Mis à neuf")
                    TypeIntervention.REPRISE_ETANCHEITE -> Pair(SolarOrange, "Reprise étanchéité")
                }
                Box(
                    modifier = Modifier
                        .background(col.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(lbl, style = MaterialTheme.typography.labelSmall, color = col, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            InfoRow(Icons.Default.LocationOn, "Adresse", client.adresse)
            Spacer(Modifier.height(10.dp))
            InfoRow(Icons.Default.EuroSymbol, "Coût", "%.2f €".format(client.cout))
            Spacer(Modifier.height(10.dp))
            InfoRow(Icons.Default.Build, "Type d'intervention", client.type.label)

            Spacer(Modifier.height(24.dp))

            OutlinedButton(
                onClick = { onDelete(client); onDismiss() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, null)
                Spacer(Modifier.width(8.dp))
                Text("Supprimer ce client")
            }
        }
    }
}

@Composable
fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
    }
}
