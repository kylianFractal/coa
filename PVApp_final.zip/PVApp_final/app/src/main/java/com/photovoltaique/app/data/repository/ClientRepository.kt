package com.photovoltaique.app.data.repository

import com.photovoltaique.app.data.dao.ClientDao
import com.photovoltaique.app.data.entity.Client
import kotlinx.coroutines.flow.Flow

class ClientRepository(private val dao: ClientDao) {
    val allClients: Flow<List<Client>> = dao.getAllClients()
    suspend fun insert(client: Client) = dao.insertClient(client)
    suspend fun delete(client: Client) = dao.deleteClient(client)
}
