package com.photovoltaique.app.ui.theme
import androidx.compose.ui.graphics.Color
val SolarOrange = Color(0xFFFF6B2B)
val SolarGreen  = Color(0xFF2ECC71)
val SolarBlue   = Color(0xFF2980B9)
val DarkBg      = Color(0xFF1A1A2E)
val DarkSurface = Color(0xFF16213E)
